import React from 'react';

export default class BaiduMapContainer extends React.Component {
    static defaultProps = {
        id: 'baidu_map_container',
    };
    componentDidMount() {
        const {id, title, enable, onSelect, initLocation, closeModal} = this.props;
        const point = initLocation ? initLocation : new BMap.Point(106.7091771, 26.62990674);
        const marker = new BMap.Marker(point);
        const self = this;
        marker.setZIndex(10000);
        marker.setTitle(title);
        marker.disableDragging();

        const map = new BMap.Map(id);
        map.enableScrollWheelZoom();
        map.enableInertialDragging();
        map.enableContinuousZoom();

        map.centerAndZoom(point, 12);
        map.addOverlay(marker);

        //添加添加事件的回调
        this.onClick =  function(e) {
            self.hasClick = true;
            marker.setPosition(e.point);
        };

        //定位
        if (!initLocation) {
            const geolocation = new BMap.Geolocation();
            geolocation.getCurrentPosition(function(r) {
                if(this.getStatus() == BMAP_STATUS_SUCCESS && !self.hasClick) {
                    marker.setPosition(r.point);
                    map.panTo(r.point);
                }
            }, {enableHighAccuracy: true});
        }

        //添加城市列表控件
        this.cityListControl = new BMap.CityListControl({
            anchor: BMAP_ANCHOR_TOP_LEFT,
            offset: new BMap.Size(60, 20),
        })
        map.addControl(this.cityListControl);

        //添加版权控件
        const cr = new BMap.CopyrightControl({anchor: BMAP_ANCHOR_BOTTOM_RIGHT});
        map.addControl(cr);
        const bs = map.getBounds();
        cr.addCopyright({id: 1, content: "<a href='#' style='font-size:14px;color:red'>信合融通版权所有</a>", bounds: bs});

        //添加缩放控件
        const navigationControl = new BMap.NavigationControl({
            anchor: BMAP_ANCHOR_TOP_LEFT,
            type: BMAP_NAVIGATION_CONTROL_LARGE,
            enableGeolocation: true
        });
        map.addControl(navigationControl);

        //添加定位控件
        const geolocationControl = new BMap.GeolocationControl();
        geolocationControl.addEventListener("locationSuccess", function(e){
            marker.setPosition(e.point);
        });
        geolocationControl.addEventListener("locationError",function(e){
            console.log(e.message);
        });
        this.geolocationControl = geolocationControl;


        // 自定义完成控件
        function DoneControl() {
            this.defaultAnchor = BMAP_ANCHOR_TOP_RIGHT;
            this.defaultOffset = new BMap.Size(10, 10);
        }
        DoneControl.prototype = new BMap.Control();
        DoneControl.prototype.initialize = function(m) {
            const div = document.createElement("div");
            const text = document.createTextNode("确定");
            div.appendChild(text);
            div.style.cursor = "pointer";
            div.style.padding = "10px 20px 10px 20px";
            div.style.border = "1px solid gray";
            div.style.backgroundColor = "#30C1B2";
            div.style.color = "#FFFFFF";
            div.style.fontSize = "20px";
            div.onclick = function(e) {
                closeModal();
                const gc = new BMap.Geocoder();
                gc.getLocation(marker.getPosition(), function(rs) {
                    onSelect(rs);
                });
            }
            m.getContainer().appendChild(div);
            return div;
        }
        this.doneControl = new DoneControl();
        if (enable) {
            map.addEventListener("click", this.onClick);
            map.addControl(this.geolocationControl);
            map.addControl(this.doneControl);
        }

        this.marker = marker;
        this.map = map;
    }
    componentWillReceiveProps(nextProps) {
        const props = this.props;
        const {initLocation, title, enable} = nextProps;
        if (initLocation) {
            setTimeout(()=>{
                this.marker.setPosition(initLocation);
                this.map.setCenter(initLocation);
            }, 100);
        }
        if (props.title !== title) {
            this.marker.setTitle(title);
        }
        if (enable !== props.enable) {
            if (enable) {
                this.map.addEventListener("click", this.onClick);
                this.map.addControl(this.geolocationControl);
                this.map.addControl(this.doneControl);
            } else {
                this.map.removeEventListener("click", this.onClick);
                this.map.removeControl(this.geolocationControl);
                this.map.removeControl(this.doneControl);
            }
        }
    }
    render() {
        const {id, className} = this.props;
        return (
            <div id={id} className={className}></div>
        )
    }
}
