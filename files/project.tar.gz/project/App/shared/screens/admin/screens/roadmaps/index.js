import React from 'react';
import { dataConnect } from 'relatejs';
import { bindActionCreators } from 'redux';
import * as roadmapActions from 'actions/roadmaps';
import { notification } from 'ant-design';
import { needLoadPage } from 'helpers/utils';
import Roadmaps from './components';

@dataConnect(
    (state) => ({ states: state.roadmaps, pageSize: 3 }),
    (dispatch) => ({
        actions : bindActionCreators(roadmapActions, dispatch),
    }),
    (props) => ({
        fragments: Roadmaps.fragments,
        variablesTypes: {
            roadmaps: {
                pageNo: 'Int!',
                pageSize: 'Int!',
                keyword: 'String!',
            },
        },
        initialVariables: {
            roadmaps: {
                pageNo: 0,
                pageSize: props.pageSize,
                keyword: '',
            },
        },
    })
)
export default class RoadmapsContainer extends React.Component {
    getRoadmaps (keyword) {
        const { relate, pageSize } = this.props;
        relate.refresh({
            variables: {
                roadmaps: {
                    pageNo: 0,
                    pageSize,
                    keyword,
                },
            },
            callback (data) {
                if (!data.roadmaps) {
                    notification.error({ description: '没有相关路线' });
                }
            },
        });
    }
    loadListPage (keyword, pageNo) {
        const { relate, pageSize, roadmaps } = this.props;
        if (needLoadPage(roadmaps, pageNo, pageSize)) {
            relate.loadPage({
                variables: {
                    roadmaps: {
                        pageNo,
                        pageSize,
                        keyword,
                    },
                },
                property:'customerList',
            });
        }
    }
    render () {
        return (
            <Roadmaps {...this.props}
                getRoadmaps={::this.getRoadmaps}
                loadListPage={::this.loadListPage} />
        );
    }
}
