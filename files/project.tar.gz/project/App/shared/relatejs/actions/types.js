export default {
    query: 'RELATE_QUERY',
    mutation: 'RELATE_MUTATION',
    removeConnector: 'RELATE_REMOVE_CONNECTOR',
    setHeader: 'RELATE_SET_HEADER',
    removeHeader: 'RELATE_REMOVE_HEADER',
    setEndpoint: 'RELATE_SET_ENDPOINT',
    setBody: 'RELATE_SET_BODY',
    removeBody: 'RELATE_REMOVE_BODY',
};
