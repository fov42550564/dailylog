import React, { PropTypes } from 'react';
import antd_form_create from 'decorators/antd_form_create';
import styles from './index.less';
import _ from 'lodash';
import verification from 'helpers/verification';
import { Button, Modal, Form, Row, Col, Input, Icon, Spin, Select, InputNumber, Upload, notification } from 'ant-design';
import BaidMap from 'components/BaiduMap';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';
import ContentDelete from 'material-ui/svg-icons/action/delete';
const FormItem = Form.Item;
const Option = Select.Option;
const Dragger = Upload.Dragger;

@antd_form_create
export default class PublishRoadmap extends React.Component {
    static fragments = {
        roadmap: {
            id: 1,
            name: 1,
            type: 1,
            price: 1,
            duration: 1,
            startPoint: {
                latitude: 1,
                longitude: 1,
                name: 1,
            },
            endPoint: {
                latitude: 1,
                longitude: 1,
                name: 1,
            },
            transitPoint: {
                latitude: 1,
                longitude: 1,
                name: 1,
            },
            truck: {
                height: 1,
                width: 1,
                length: 1,
                capacity: 1,
                imgList: 1,
            },
            remark: 1,
        },
    };
    state = {
        waiting : false,
        editing: this.props.operType===0,
        fileList: [],
        visible: false,
        title: '',
        roadmap: _.cloneDeep(this.props.roadmap) || ( this.props.operType===0 ? {
            type: 0,
            price: 100,
            duration: 10,
            truck: {
                height: 3,
                width: 3,
                length: 10,
                capacity: 30,
            },
            transitPoint: [],
        } : {} )
    }
    componentWillReceiveProps(nextProps) {
        if (this.props.operType === 1) {
            const { roadmap } = nextProps;
            const fileList = roadmap.truck ? roadmap.truck.imgList.map((o, i)=>({url: o, status: 'done', uid: -i})) : [];
            if (!_.isEqual(roadmap, this.props.roadmap)) {
                this.setState({roadmap: _.cloneDeep(roadmap), fileList });
            }
        }
    }
    handleSubmit (e) {
        e.preventDefault();
        const {roadmap, fileList, editing} = this.state;
        if (editing) {
            const self = this;
            const { actions, form, history, operType, roadmapId } = this.props;
            const sumbit = operType === 0 ? actions.publishRoadmap : actions.modifyRoadmap;
            form.validateFields((errors, value) => {
                if (errors) {
                    _.mapValues(errors, (item) => {
                        notification.error({ description: _.last(item.errors.map((o) => o.message)) });
                    });
                    return;
                }
                value.startPoint = roadmap.startPoint;
                value.endPoint = roadmap.endPoint;
                const transitPoint = [];
                for (const index in roadmap.transitPoint) {
                    const item = roadmap.transitPoint[index];
                    if (!item.removed) {
                        transitPoint.push({latitude: item.latitude, longitude: item.longitude, name: item.name});
                        delete value['transitPoint' + index];
                    }
                }
                value.transitPoint = transitPoint;

                value.truck = {
                    capacity: value.capacity,
                    length: value.length,
                    width: value.width,
                    height: value.height,
                    imgList: fileList.map(o=>o.url||o.response.context.url),
                };
                delete value.capacity;
                delete value.length;
                delete value.width;
                delete value.height;

                value.type = value.type==='整车' ? 0 : 1;
                if (operType === 1) {
                    value.roadmapId = roadmapId;
                }

                self.setState({ waiting: true });
                sumbit(value, (data) => {
                    self.setState({ waiting: false });
                    if (data.success) {
                        notification.success({ description:  (operType === 0 ? '发布' : '修改' )+'成功' });
                        if (operType === 0) {
                            // history.push({ pathname: '/admin/applyPublishCard/result', state: data.context });
                        } else {
                            self.setState({editing: false});
                        }
                    } else {
                        notification.error({ description: data.msg });
                    }
                });
            });
        } else {
            this.setState({ editing: true });
        }
    }
    getBase64 (img, callback) {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.readAsDataURL(img);
    }
    onChange ({fileList}) {
        this.setState({ fileList });
    }
    showBaiduMap(index) {
        const { editing, roadmap } = this.state;
        const { startPoint , endPoint, transitPoint } = roadmap;
        const { longitude , latitude } = (index===0 ? startPoint : index===1 ?  endPoint : transitPoint[index-2])||{};

        this.mapIndex = index;
        this.setState({
            visible: true,
            title: (index===0 ? '起' : index===1 ?  '终' : '途经')+'点',
            initLocation: longitude && latitude ? new BMap.Point(longitude, latitude) : undefined,
        });
    }
    handleCancel() {
        this.setState({ visible: false});
    }
    closeModal() {
        this.setState({ visible: false, waiting: true});
    }
    getPointText(p) {
        return p.name && p.latitude && p.longitude ? p.name+'('+p.latitude+','+p.longitude+')' : '';
    }
    onMapSelect(pos) {
        const {address, point, point: {lat, lng} } = pos;
        const { form } = this.props;
        const { roadmap } = this.state;
        const index = this.mapIndex;
        const p = {name: address, latitude: lat, longitude: lng};
        const text = this.getPointText(p);

        if (index === 0) {
            roadmap.startPoint = p;
            form.setFieldsValue({ startPoint: text});
        } else if (index === 1) {
            roadmap.endPoint = p;
            form.setFieldsValue({ endPoint: text});
        } else {
            roadmap.transitPoint[index-2] = p;
            form.setFieldsValue({ ['transitPoint'+(index-2)]: text});
        }
        this.setState({waiting : false, roadmap });
    }
    onSelect(value) {
        const { roadmap } = this.state;
        roadmap.type = value*1;
        this.setState({roadmap});
    }
    addTransitPointItem(index) {
        const { roadmap, roadmap: { transitPoint } } = this.state;
        const { form } = this.props;

        if (index === undefined) {
            transitPoint.push({});
        } else {
            transitPoint.splice(index+1, 0, {});
        }
        for (const i in transitPoint) {
            form.setFieldsValue({ ['transitPoint'+i]:  this.getPointText(transitPoint[i])});
        }

        this.setState({ roadmap });
    }
    removeTransitPointItem(index) {
        const { roadmap } = this.state;
        roadmap.transitPoint[index].removed = true;
        this.setState({ roadmap });
    }
    render () {
        const { form, operType } = this.props;
        const { waiting, editing, fileList, visible, title, initLocation, roadmap } = this.state;
        const {name, type, price, duration, truck={}, startPoint={}, endPoint={}, transitPoint=[], remark} = roadmap;
        const { getFieldDecorator, getFieldError, isFieldValidating } = form;
        const nameDecorator = getFieldDecorator('name', {
            initialValue: name,
            rules: [
                { required: true, message: '请填写店铺地址' },
            ],
        });
        const typeDecorator = getFieldDecorator('type', {
            initialValue: type===0 ? '整车' : '零担',
            rules: [
                { required: true, message: '请选择路线类型' },
            ],
        });
        const priceDecorator = getFieldDecorator('price', {
            initialValue: price,
            rules: [
                { required: true, message: '请填写价格' },
            ],
        });
        const durationDecorator = getFieldDecorator('duration', {
            initialValue: duration,
            rules: [
                { required: true, message: '请填写时长' },
            ],
        });
        const lengthDecorator = getFieldDecorator('length', {
            initialValue: truck.length,
            rules: [
                { required: true, message: '请填写车身长度' },
            ],
        });
        const widthDecorator = getFieldDecorator('width', {
            initialValue: truck.width,
            rules: [
                { required: true, message: '请填写车身宽度' },
            ],
        });
        const heightDecorator = getFieldDecorator('height', {
            initialValue: truck.height,
            rules: [
                { required: true, message: '请填写车身高度' },
            ],
        });
        const capacityDecorator = getFieldDecorator('capacity', {
            initialValue: truck.capacity,
            rules: [
                { required: true, message: '请填写货车载重' },
            ],
        });
        const startPointDecorator = getFieldDecorator('startPoint', {
            initialValue: this.getPointText(startPoint),
            rules: [
                { required: true, message: '请设置起点' },
            ],
        });
        const endPointDecorator = getFieldDecorator('endPoint', {
            initialValue: this.getPointText(endPoint),
            rules: [
                { required: true, message: '请设置终点' },
            ],
        });
        const remarkDecorator = getFieldDecorator('remark', {
            initialValue: remark,
        });
        const uploadButton = (
            <div className={styles.uploadButton}>
                <Icon type="plus" />
            </div>
        );
        const uploadProps = {
            name: 'file',
            action: '/uploadFile',
            supportServerRender: true,
        };
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 12 },
        };
        const formItemLayoutInner = {
            labelCol: { span: 7 },
            wrapperCol: { span: 10 },
        };
        let textIndex = 0;
        const length = _.reject(transitPoint, (o)=>o.removed).length;
        return (
            <div className={styles.container}>
                <div className={styles.titleContainer}>
                    <div className={styles.title}>商家信息</div>
                    <Button type='ghost' onClick={::this.handleSubmit} loading={waiting}>{operType===0 ? '发布': !editing ? '修改' : '确认修改'}</Button>
                </div>
                <Form horizontal className={!editing ? styles.editForm : ''}>
                    <FormItem
                        {...formItemLayout}
                        label='路线名称:'
                        hasFeedback
                        >
                        {nameDecorator(
                            <Input disabled={!editing}  placeholder='请输入路线名称' />
                        )}
                    </FormItem>
                    <FormItem
                        {...formItemLayout}
                        label='类型:'
                        hasFeedback
                        >
                        {typeDecorator(
                            <Select disabled={!editing} placeholder='请选择路线类型' onSelect={::this.onSelect} >
                                <Option value="0">整车</Option>
                                <Option value="1">零担</Option>
                            </Select>
                        )}
                    </FormItem>
                    <FormItem
                        {...formItemLayout}
                        label='价格:'
                        hasFeedback
                        >
                        {priceDecorator(
                            <InputNumber disabled={!editing}  min={1} step={100} />
                        )}
                        <span className={styles.unit}>元/{type===0 ? '车' : '吨'}</span>
                    </FormItem>
                    <FormItem
                        {...formItemLayout}
                        label='时长:'
                        hasFeedback
                        >
                        {durationDecorator(
                            <InputNumber disabled={!editing} min={1} step={1} />
                        )}
                        <span className={styles.unit}>小时</span>
                    </FormItem>
                    {
                        type===0 &&
                        <div className={styles.subForm}>
                            <FormItem
                                {...formItemLayout}
                                label='货车信息:'
                                >
                            </FormItem>
                            <FormItem
                                {...formItemLayoutInner}
                                label='车长:'
                                hasFeedback
                                >
                                {lengthDecorator(
                                    <InputNumber disabled={!editing} min={1} step={0.1} />
                                )}
                                <span className={styles.unit}>米</span>
                            </FormItem>
                            <FormItem
                                {...formItemLayoutInner}
                                label='车宽:'
                                hasFeedback
                                >
                                {widthDecorator(
                                    <InputNumber disabled={!editing} min={1} step={0.1} />
                                )}
                                <span className={styles.unit}>米</span>
                            </FormItem>
                            <FormItem
                                {...formItemLayoutInner}
                                label='车高:'
                                hasFeedback
                                >
                                {heightDecorator(
                                    <InputNumber disabled={!editing} min={1} step={0.1} />
                                )}
                                <span className={styles.unit}>米</span>
                            </FormItem>
                            <FormItem
                                {...formItemLayoutInner}
                                label='载重:'
                                hasFeedback
                                >
                                {capacityDecorator(
                                    <InputNumber disabled={!editing} min={1} step={0.1} />
                                )}
                                <span className={styles.unit}>吨</span>
                            </FormItem>
                            <FormItem
                                {...formItemLayoutInner}
                                label='照片:'
                                hasFeedback
                                >
                                <Upload
                                    {...uploadProps}
                                    disabled={!editing}
                                    accept='.jpg,.png'
                                    listType="picture-card"
                                    fileList={fileList}
                                    onChange={::this.onChange}
                                    >
                                    {fileList.length >= 4 ? null : uploadButton}
                                </Upload>
                            </FormItem>
                        </div>
                    }
                    <FormItem
                        {...formItemLayout}
                        label='起点:'
                        hasFeedback
                        >
                        <div className={styles.iconButtonContainer}>
                            <Button loading={waiting} type='dashed' className={styles.iconButton} onClick={this.showBaiduMap.bind(this, 0)}>
                                <img src='/img/common/location.png' className={styles.icon} />
                            </Button>
                            {startPointDecorator(
                                <Input readOnly placeholder='请选择起点' />
                            )}
                        </div>
                    </FormItem>
                    <FormItem
                        {...formItemLayout}
                        label='终点:'
                        hasFeedback
                        >
                        <div className={styles.iconButtonContainer}>
                            <Button loading={waiting} type='dashed' className={styles.iconButton} onClick={this.showBaiduMap.bind(this, 1)}>
                                <img src='/img/common/location.png' className={styles.icon} />
                            </Button>
                            {endPointDecorator(
                                <Input readOnly placeholder='请选择起点' />
                            )}
                        </div>
                    </FormItem>
                    {
                        !length ?
                        <FormItem
                            {...formItemLayout}
                            label='途经点:'
                            hasFeedback
                            >
                            <div className={styles.iconButtonContainer}>
                                <FloatingActionButton className={styles.iconAdd} onTouchTap={::this.addTransitPointItem}>
                                    <ContentAdd />
                                </FloatingActionButton>
                            </div>
                        </FormItem>
                        :
                        transitPoint.map((item, i)=> {
                            !item.removed && (textIndex++);
                            return item.removed ? null : (
                                <FormItem
                                    key={i}
                                    {...formItemLayout}
                                    label={'途经点'+(length>1 ? textIndex: '')+':'}
                                    hasFeedback
                                    >
                                    <div className={styles.iconButtonContainer}>
                                        {
                                            editing &&
                                            <FloatingActionButton secondary className={styles.iconRemove}  onTouchTap={this.removeTransitPointItem.bind(this, i)}>
                                                <ContentDelete />
                                            </FloatingActionButton>
                                        }
                                        {
                                            editing &&
                                            <FloatingActionButton className={styles.iconAdd}  onTouchTap={this.addTransitPointItem.bind(this, i)}>
                                                <ContentAdd />
                                            </FloatingActionButton>
                                        }
                                        <Button loading={waiting} type='dashed' className={styles.iconButton} onClick={this.showBaiduMap.bind(this, 2+i)}>
                                            <img src='/img/common/location.png' className={styles.icon} />
                                        </Button>
                                        {getFieldDecorator('transitPoint'+i, {
                                            initialValue: this.getPointText(item),
                                            rules: [
                                                { required: true, message: '请设置终点' },
                                            ],
                                        })(
                                            <Input readOnly placeholder='请选择途经点' />
                                        )}
                                    </div>
                                </FormItem>
                            )
                        })
                    }
                    <FormItem
                        {...formItemLayout}
                        label='备注:'
                        hasFeedback
                        >
                        {remarkDecorator(
                            <Input disabled={!editing} type='textarea' rows={4} />
                        )}
                    </FormItem>
                </Form>
                <Modal title={'选择'+title} visible={visible} footer={null} className={styles.modal} onCancel={::this.handleCancel} >
                    <BaidMap className={styles.mapContainer} onSelect={::this.onMapSelect} title={title} initLocation={initLocation} enable={editing} closeModal={::this.closeModal}/>

                </Modal>
            </div>
        );
    }
}
