import {
    GraphQLObjectType,
    GraphQLInt,
    GraphQLString,
    GraphQLList,
} from 'graphql';
import { authorize } from '../../authorize';
import { roadmapType } from '../../types/roadmap';
import { post, urls } from 'helpers/api';

const roadmapsType = new GraphQLObjectType({
    name: 'roadmapsType',
    fields: {
        count: { type: GraphQLInt },
        roadmapList: { type: new GraphQLList(roadmapType) },
    },
});

export default {
    type: roadmapsType,
    args: {
        keyword: {
            type: GraphQLString,
        },
        pageNo: {
            type: GraphQLInt,
        },
        pageSize: {
            type: GraphQLInt,
        },
    },
    async resolve (root, params, options) {
        authorize(root);
        let ret = await post(urls.roadmaps, params, root) || {};
        return ret.success ? ret.context : {};
    },
};
