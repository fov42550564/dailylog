import * as user from './user';
import * as shop from './shop';
import * as roadmap from './roadmap';

export default {
    ...user,
    ...shop,
    ...roadmap,
};
