import adminRouter from './admin';
import authRouter from './auth';
import publicRouter from './public';

export default {
    adminRouter,
    authRouter,
    publicRouter,
};
