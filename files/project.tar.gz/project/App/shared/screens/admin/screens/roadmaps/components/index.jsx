import React from 'react';
import { findDOMNode } from 'react-dom';
import { Table, Input, Button, Spin, Modal, InputNumber, notification } from 'ant-design';
import styles from './index.less';
import verification from 'helpers/verification';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';
import _ from 'lodash';
const Search = Input.Search;

const columns = [{
    title: '名称',
    dataIndex: 'name',
}, {
    title: '类型',
    dataIndex: 'type',
    render: (data) => data===0 ? '整车' : '零担',
    width: 60,
}, {
    title: '单价',
    dataIndex: 'price',
    width: 100,
}, {
    title: '时长',
    dataIndex: 'duration',
    width: 60,
}, {
    title: '起点',
    dataIndex: 'startPoint',
    render: (data) => data.name,
}, {
    title: '终点',
    dataIndex: 'endPoint',
    render: (data) => data.name,
}, {
    title: '途经点数',
    dataIndex: 'transitPoint',
    render: (data) => data.length,
}, {
    title: '备注',
    dataIndex: 'remark',
}];

export default class Roadmaps extends React.Component {
    static fragments = {
        roadmaps: {
            count: 1,
            roadmapList: {
                id: 1,
                name: 1,
                type: 1,
                price: 1,
                duration: 1,
                startPoint: {
                    latitude: 1,
                    longitude: 1,
                    name: 1,
                },
                endPoint: {
                    latitude: 1,
                    longitude: 1,
                    name: 1,
                },
                transitPoint: {
                    latitude: 1,
                    longitude: 1,
                    name: 1,
                },
                truck: {
                    height: 1,
                    width: 1,
                    length: 1,
                    capacity: 1,
                    imgList: 1,
                },
                remark: 1,
            },
        },
    };
    state = { current: this.props.lastCurrent || 1, keyword: '' }
    onRowClick (record, index) {
        const { relate, history, roadmaps } = this.props;
        const { current } = this.state;
        relate.setKeepData({ lastSelectIndex: index, lastCurrent: current });
        history.push({ pathname: '/admin/roadmaps/detail', state: {  operType: 1, roadmapId: record.id, roadmaps } });
    }
    rowClassName (record, index) {
        const { lastCurrent, lastSelectIndex } = this.props;
        const { current } = this.state;
        return current === lastCurrent && lastSelectIndex === index ? styles.selected : '';
    }
    onSearch (keyword) {
        const { getRoadmaps } = this.props;
        this.setState({ current: 1, keyword });
        getRoadmaps(keyword);
    }
    showPublishRoadmap() {
        const { history, roadmaps } = this.props;
        history.push({ pathname: '/admin/roadmaps/detail', state: { operType: 0, roadmaps } });
    }
    render () {
        const self = this;
        const { current, keyword } = this.state;
        const { states, roadmaps = {}, loadListPage, loading, loadingPage } = this.props;
        const pagination = {
            total: roadmaps.count,
            showSizeChanger: false,
            current,
            pageSize: 3,
            onChange (current) {
                self.setState({ current });
                loadListPage(keyword, current - 1);
            },
        };
        return (
            <div className={styles.container}>
                <div className={styles.searchContainer}>
                    {
                        loading ?
                            <div style={{ textAlign:'center' }}>
                                <Spin />
                                <div>正在查找...</div>
                            </div>
                        :
                            <Search className={styles.search} placeholder='输入关键字查找' onSearch={::this.onSearch} />
                    }
                    {
                        !loading &&
                        <div className={styles.iconAddContainer}>
                            <FloatingActionButton secondary className={styles.iconAdd} onTouchTap={::this.showPublishRoadmap}>
                                <ContentAdd />
                            </FloatingActionButton>
                            <span className={styles.iconAddText}>
                                发布路线
                            </span>
                        </div>
                    }
                </div>
                <div className={styles.tableContainer}>
                    <Table
                        loading={loadingPage}
                        columns={columns}
                        dataSource={roadmaps.roadmapList}
                        pagination={pagination}
                        rowClassName={::this.rowClassName}
                        onRowClick={::this.onRowClick} />
                </div>
            </div>
        );
    }
}
