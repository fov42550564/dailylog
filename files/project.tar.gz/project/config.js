const API_HOST = '120.25.96.74';
const DB_HOST = '120.25.96.74';
module.exports =  {
    port: 3001,
    devPort: 3011,
    apiServer: 'http://'+API_HOST+':3000/api/',
    dbServer: 'mongodb://'+DB_HOST+'/card',
    baiduMapSK: 'GLnwGRYn42ptcObzmecOHqovw3Pkqm80',
}
