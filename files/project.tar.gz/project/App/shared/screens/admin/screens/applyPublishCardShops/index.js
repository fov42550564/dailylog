import React from 'react';
import { dataConnect } from 'relatejs';
import { bindActionCreators } from 'redux';
import * as shopActions from 'actions/shops';
import { notification } from 'ant-design';
import { needLoadPage } from 'helpers/utils';
import ApplyPublishCardShops from './components';

@dataConnect(
    (state) => ({ pageSize: 3 }),
    (dispatch) => ({
        actions : bindActionCreators(shopActions, dispatch),
    }),
    (props) => ({
        fragments: ApplyPublishCardShops.fragments,
        variablesTypes: {
            applyPublishCardShops: {
                pageNo: 'Int!',
                pageSize: 'Int!',
                keyword: 'String!',
            },
        },
        initialVariables: {
            applyPublishCardShops: {
                pageNo: 0,
                pageSize: props.pageSize,
                keyword: '',
            },
        },
    })
)
export default class ApplyShopsContainer extends React.Component {
    getApplyShops (keyword) {
        const { relate, pageSize } = this.props;
        relate.refresh({
            variables: {
                applyPublishCardShops: {
                    pageNo: 0,
                    pageSize,
                    keyword,
                },
            },
            callback (data) {
                if (!data.applyPublishCardShops) {
                    notification.error({ description: '没有相关用户' });
                }
            },
        });
    }
    loadListPage (keyword, pageNo) {
        const { relate, pageSize, applyPublishCardShops } = this.props;
        if (needLoadPage(applyPublishCardShops, pageNo, pageSize)) {
            relate.loadPage({
                variables: {
                    applyPublishCardShops: {
                        pageNo,
                        pageSize,
                        keyword,
                    },
                },
                property:'shopList',
            });
        }
    }
    render () {
        return (
            <ApplyPublishCardShops {...this.props}
                getApplyShops={::this.getApplyShops}
                loadListPage={::this.loadListPage} />
        );
    }
}
