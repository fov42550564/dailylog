import React from 'react';
import { dataConnect } from 'relatejs';
import { bindActionCreators } from 'redux';
import * as roadmapActions from 'actions/roadmaps';
import { notification } from 'ant-design';
import RoadmapDetail from './components';

@dataConnect(
    (state) => {
        const { operType, roadmapId, roadmap, roadmaps } = state.router.location.state;
        return { operType, roadmapId, roadmap, roadmaps, keepLastKeepData: true };
    },
    (dispatch) => ({
        actions : bindActionCreators(roadmapActions, dispatch),
    }),
    (props) => {
        return {
            manualLoad: !!props.roadmap || !props.roadmapId,
            fragments: RoadmapDetail.fragments,
            variablesTypes: {
                roadmap: {
                    roadmapId: 'ID!',
                },
            },
            initialVariables: {
                roadmap: {
                    roadmapId: props.roadmapId,
                },
            },
        };
    }
)
export default class RoadmapDetailContainer extends React.Component {
    render () {
        return (
            <RoadmapDetail {...this.props} />
        );
    }
}
