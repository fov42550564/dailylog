import { mutation } from 'relatejs';

export function publishRoadmap (data, callback) {
    return (dispatch, getState) => {
        return mutation({
            fragments: {
                publishRoadmap: { success: 1, msg: 1 },
            },
            variables: {
                publishRoadmap: {
                    data: {
                        value: data,
                        type: 'roadmapInputType!',
                    },
                },
            },
        }, (result) => {
            callback(result.publishRoadmap);
        })(dispatch, getState);
    };
}
export function modifyRoadmap (data, callback) {
    return (dispatch, getState) => {
        return mutation({
            fragments: {
                modifyRoadmap: { success: 1, msg: 1 },
            },
            variables: {
                modifyRoadmap: {
                    data: {
                        value: data,
                        type: 'roadmapInputType!',
                    },
                },
            },
        }, (result) => {
            callback(result.modifyRoadmap);
        })(dispatch, getState);
    };
}
