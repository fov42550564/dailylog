import routes from 'routers/public';
import renderRoutes from './helpers/render-routes';

renderRoutes(routes);
