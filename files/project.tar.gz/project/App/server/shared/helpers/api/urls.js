var { apiServer } = require('../../../../../config.js');
var server = apiServer + 'cardm/';
var xxserver = 'http://localhost:3000/api/shipper/';

module.exports = {
    notify: apiServer + 'notify', // notify列表

    login: server + 'login', // 登录
    register: server + 'register', // 注册
    forgotPwd: server + 'findPassword', // 忘记密码
    modifyPassword: server + 'modifyPassword', // 修改密码

    applyPublishCardShops: server + 'getApplyPublishCardShopList', // 获取申请发卡的商家列表
    applyPublishCardShop: server + 'getApplyPublishCardShopDetail', // 获取申请商家的详情
    acceptPublishCardApply: server + 'acceptPublishCardApply', // 同意发卡的申请
    refusePublishCardApply: server + 'refusePublishCardApply', // 拒绝发卡的申请

    //路线
    roadmaps: xxserver + 'getRoadmapList', // 获取路线列表
    roadmap: xxserver + 'getRoadmapDetail', // 获取路线详情
    publishRoadmap: xxserver + 'publishRoadmap', // 发布路线
    modifyRoadmap: xxserver + 'modifyRoadmap', // 修改路线
};
