import 'babel-polyfill';

import routes from 'routers/admin';
import renderRoutes from './helpers/render-routes';

renderRoutes(routes);
