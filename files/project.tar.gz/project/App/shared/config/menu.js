export default [
    {
        label: '路线',
        icon: 'home',
        link: '/admin/roadmaps',
    },
    {
        label: '申请发卡的商家',
        icon: 'home',
        link: '/admin/applyPublishCardShops',
    },
];
