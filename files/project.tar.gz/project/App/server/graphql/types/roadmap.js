import {
    GraphQLInputObjectType,
    GraphQLObjectType,
    GraphQLString,
    GraphQLFloat,
    GraphQLInt,
    GraphQLID,
    GraphQLList,
} from 'graphql';

const truckType = new GraphQLObjectType({
    name: 'truckType',
    fields: {
        capacity: { type: GraphQLFloat }, // 载重
        length: { type: GraphQLFloat }, // 车身长度
        width: { type: GraphQLFloat }, // 车身宽度
        height: { type: GraphQLFloat }, // 车身高度
        imgList:  { type: new GraphQLList(GraphQLString) }, //图片列表
    },
});

const pointType = new GraphQLObjectType({
    name: 'pointType',
    fields: {
        latitude: { type: GraphQLFloat }, // 经度
        longitude: { type: GraphQLFloat }, // 纬度
        name: { type: GraphQLString }, // 地名
    },
});

export const roadmapType = new GraphQLObjectType({
    name: 'roadmapType',
    fields: {
        id: { type: GraphQLID },
        type: { type: GraphQLInt }, //0: 整车 1: 零担
        name: { type: GraphQLString },
        startPoint: { type: pointType },
        endPoint: { type: pointType },
        transitPoint:  { type: new GraphQLList(pointType) },
        price: { type: GraphQLFloat },
        duration: { type: GraphQLFloat },
        truck: { type: truckType },
        remark: { type: GraphQLString },
    },
});

const truckInputType = new GraphQLInputObjectType({
    name: 'truckInputType',
    fields: {
        capacity: { type: GraphQLFloat }, // 载重
        length: { type: GraphQLFloat }, // 车身长度
        width: { type: GraphQLFloat }, // 车身宽度
        height: { type: GraphQLFloat }, // 车身高度
        imgList:  { type: new GraphQLList(GraphQLString) }, //图片列表
    },
});

const pointInputType = new GraphQLInputObjectType({
    name: 'pointInputType',
    fields: {
        latitude: { type: GraphQLFloat }, // 经度
        longitude: { type: GraphQLFloat }, // 纬度
        name: { type: GraphQLString }, // 地名
    },
});


export const roadmapInputType = new GraphQLInputObjectType({
    name: 'roadmapInputType',
    fields: {
        roadmapId: { type: GraphQLID },
        type: { type: GraphQLInt }, //0: 整车 1: 零担
        name: { type: GraphQLString },
        startPoint: { type: pointInputType },
        endPoint: { type: pointInputType },
        transitPoint:  { type: new GraphQLList(pointInputType) },
        price: { type: GraphQLFloat },
        duration: { type: GraphQLFloat },
        truck: { type: truckInputType },
        remark: { type: GraphQLString },
    },
});
