import React from 'react';
import { Route, IndexRoute } from 'react-router';
import request from 'superagent';
import Admin from 'screens/admin';
import Roadmaps from 'screens/admin/screens/roadmaps';
import RoadmapDetail from 'screens/admin/screens/roadmaps/screens/roadmapDetail';
import ApplyShops from 'screens/admin/screens/applyPublishCardShops';
import ApplyShopDetail from 'screens/admin/screens/applyPublishCardShops/screens/detail';


let firstEntry = true;

function authenticate (nextState, replaceState, callback) {
    if (typeof window !== 'undefined' && !firstEntry) {
        request
        .post('/graphql')
        .set('Content-Type', 'application/json')
        .set('Accept', 'application/json')
        .send({
            query: 'query { session }',
        })
        .end((error, result) => {
            if (error || !result.body.data.session) {
                window.location.href = '/admin/login';
            } else {
                callback();
            }
        });
    } else {
        firstEntry = false;
        callback();
    }
}

export default [
    <Route name='admin' path='/admin' component={Admin}>
        <IndexRoute component={ApplyShops} onEnter={authenticate} />
        <Route name='adminRoadmaps' path='roadmaps'>
            <IndexRoute component={Roadmaps} onEnter={authenticate} />
            <Route name='adminRoadmapDetail' path='detail' component={RoadmapDetail} onEnter={authenticate} />
        </Route>
        <Route name='adminApplyShops' path='applyPublishCardShops'>
            <IndexRoute component={ApplyShops} onEnter={authenticate} />
            <Route name='adminApplyShopDetail' path='detail' component={ApplyShopDetail} onEnter={authenticate} />
        </Route>
    </Route>,
];
