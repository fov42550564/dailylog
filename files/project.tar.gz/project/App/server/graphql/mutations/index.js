import * as user from './user';
import * as shop from './shop';

export default {
    ...user,
    ...shop,
};
