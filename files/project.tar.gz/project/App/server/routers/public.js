import { Router } from 'express';

const publicRouter = new Router();

export default publicRouter;
