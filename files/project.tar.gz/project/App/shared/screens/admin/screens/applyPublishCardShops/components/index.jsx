import React from 'react';
import { findDOMNode } from 'react-dom';
import { Table, Input, Button, Spin, Modal, InputNumber, notification } from 'ant-design';
import styles from './index.less';
import verification from 'helpers/verification';
import _ from 'lodash';
const Search = Input.Search;

const columns = [{
    title: '商家名称',
    dataIndex: 'shopName',
}, {
    title: '申请时间',
    dataIndex: 'applyPublishCardTime',
}, {
    title: '申请总额',
    dataIndex: 'applyAmount',
}, {
    title: '商家电话',
    dataIndex: 'shopPhone',
}, {
    title: '商家地址',
    dataIndex: 'shopAddress',
}];

export default class ApplyPublishCardShops extends React.Component {
    static fragments = {
        applyPublishCardShops: {
            count: 1,
            shopList: {
                shopId: 1,
                shopName: 1,
                shopPhone: 1,
                shopAddress: 1,
                applyPublishCardTime: 1,
                applyAmount: 1,
            },
        },
    };
    state = { current: this.props.lastCurrent || 1, keyword: '' }
    onRowClick (record, index) {
        const { relate, history, applyPublishCardShops } = this.props;
        const { current } = this.state;
        relate.setKeepData({ lastSelectIndex: index, lastCurrent: current }, '/admin/applyPublishCardShops');
        history.push({ pathname: '/admin/applyPublishCardShops/detail', state: { shopId: record.shopId, applyPublishCardShops } });
    }
    rowClassName (record, index) {
        const { lastCurrent, lastSelectIndex } = this.props;
        const { current } = this.state;
        return current === lastCurrent && lastSelectIndex === index ? styles.selected : '';
    }
    onSearch (keyword) {
        const { getApplyShops } = this.props;
        if (!verification.checkPhone(keyword)) {
            notification.error({ description: '请输入有效的电话号码' });
            return;
        }
        this.setState({ current: 1, keyword: keyword });
        getApplyShops(keyword);
    }
    render () {
        const self = this;
        const { current, keyword } = this.state;
        const { states, applyPublishCardShops = {}, loadListPage, loading, loadingPage } = this.props;
        const pagination = {
            total: applyPublishCardShops.count,
            showSizeChanger: false,
            current,
            pageSize: 3,
            onChange (current) {
                self.setState({ current });
                loadListPage(keyword, current - 1);
            },
        };
        return (
            <div className={styles.container}>
                <div className={styles.searchContainer}>
                    {
                        loading ?
                            <div style={{ textAlign:'center' }}>
                                <Spin />
                                <div>正在查找...</div>
                            </div>
                        :
                            <Search className={styles.search} placeholder='输入电话号码查找' onSearch={::this.onSearch} />
                    }
                </div>
                <div className={styles.tableContainer}>
                    <Table
                        loading={loadingPage}
                        columns={columns}
                        dataSource={applyPublishCardShops.shopList}
                        pagination={pagination}
                        rowClassName={::this.rowClassName}
                        onRowClick={::this.onRowClick} />
                </div>
            </div>
        );
    }
}
