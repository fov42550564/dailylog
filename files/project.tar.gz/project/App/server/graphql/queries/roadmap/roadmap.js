import {
    GraphQLID,
} from 'graphql';
import { authorize } from '../../authorize';
import { roadmapType } from '../../types/roadmap';
import { post, urls } from 'helpers/api';

export default {
    type: roadmapType,
    args: {
        roadmapId: {
            type: GraphQLID,
        },
    },
    async resolve (root, params, options) {
        authorize(root);
        let ret = await post(urls.roadmap, params, root) || {};
        return ret.success ? ret.context : undefined;
    },
};
