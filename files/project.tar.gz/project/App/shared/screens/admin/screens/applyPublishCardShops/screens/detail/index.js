import React from 'react';
import { dataConnect } from 'relatejs';
import { bindActionCreators } from 'redux';
import * as shopActions from 'actions/shops';
import { notification } from 'ant-design';
import Detail from './components';
import _ from 'lodash';

@dataConnect(
    (state) => {
        const { shopId, applyPublishCardShops } = state.router.location.state;
        return { shopId, applyPublishCardShops, keepLastKeepData: true };
    },
    (dispatch) => ({
        actions : bindActionCreators(shopActions, dispatch),
    }),
    (props) => {
        return {
            fragments: Detail.fragments,
            variablesTypes: {
                applyPublishCardShop: {
                    shopId: 'String!',
                },
            },
            initialVariables: {
                applyPublishCardShop: {
                    shopId: props.shopId,
                },
            },
            mutations: {
                acceptPublishCardApply ({ state, data }) {
                    if (data.success) {
                        props.applyPublishCardShops.count--;
                        _.remove(props.applyPublishCardShops.shopList, (item) => item.shopId === props.shopId);
                    }
                },
                refusePublishCardApply ({ state, data }) {
                    if (data.success) {
                        props.applyPublishCardShops.count--;
                        _.remove(props.applyPublishCardShops.shopList, (item) => item.shopId === props.shopId);
                    }
                },
            },
        };
    }
)
export default class DetailContainer extends React.Component {
    render () {
        return (
            <Detail {...this.props} />
        );
    }
}
