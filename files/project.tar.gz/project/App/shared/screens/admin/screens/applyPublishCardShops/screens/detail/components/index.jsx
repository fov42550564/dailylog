import React from 'react';
import { Table, Input, Form, Button, Spin, Modal, InputNumber, notification } from 'ant-design';
import styles from './index.less';
import moment from 'moment';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';

export default class Detail extends React.Component {
    static fragments = {
        applyPublishCardShop: {
            shopName: 1,
            shopLogo: 1,
            shopSign: 1,
            shopPhone: 1,
            shopAddress: 1,
            applyAmount: 1,
            applyPublishCardTime: 1,
            registerCapital: 1,
            legalName: 1,
            legalPhone: 1,
            legalIDFront: 1,
            legalIDBack: 1,
            license: 1,
            taxCertificate: 1,
            organizationCertificate: 1,
            openAccountCertificate: 1,
        },
    };
    state = { waiting: false, passed: 0 }
    handleAcceptApply () {
        const self = this;
        const { actions, shopId } = this.props;
        self.setState({ waiting: true });
        actions.acceptPublishCardApply(shopId, (data) => {
            self.setState({ waiting: false, passed: 1 });
            if (data.success) {
                Modal.success({
                    content: '审核成功',
                });
            } else {
                notification.error({ description: data.msg });
            }
        });
    }
    confirmAcceptApply () {
        const self = this;
        Modal.confirm({
            title: '批准确认',
            content: (
                <div className={styles.confirmContainer}>
                    确定批准该商家的发卡权限的申请吗？
                </div>
            ),
            okText: '确定',
            cancelText: '取消',
            onOk () {
                self.handleAcceptApply();
            },
        });
    }
    handleRefuseApply (reason) {
        const self = this;
        const { actions, shopId } = this.props;
        self.setState({ waiting: true });
        actions.refusePublishCardApply(shopId, reason, (data) => {
            self.setState({ waiting: false, passed: 2 });
            if (data.success) {
                Modal.success({
                    content: '已经拒绝了该店的申请',
                });
            } else {
                notification.error({ description: data.msg });
            }
        });
    }
    confirmRefuseApply () {
        const self = this;
        let reason = '';
        Modal.confirm({
            title: '请填写拒绝的理由',
            content: (
                <MuiThemeProvider>
                    <TextField defaultValue={reason} floatingLabelText='拒绝理由' multiLine rowsMax={3} onChange={(e, value) => { reason = value; }} />
                </MuiThemeProvider>
            ),
            okText: '确定',
            cancelText: '取消',
            onOk () {
                if (!reason) {
                    notification.error({ description: '请填写拒绝理由' });
                } else {
                    self.handleRefuseApply(reason);
                }
            },
        });
    }
    render () {
        const self = this;
        const { waiting, passed } = this.state;
        const { applyPublishCardShop, loading } = this.props;
        const {
            shopName,
            shopLogo,
            shopSign,
            shopPhone,
            shopAddress,
            applyAmount,
            applyPublishCardTime,
            registerCapital,
            legalName,
            legalPhone,
            legalIDFront,
            legalIDBack,
            license,
            taxCertificate,
            organizationCertificate,
            openAccountCertificate,
        } = applyPublishCardShop || {};
        return (
            <div className={styles.container}>
                {
                    !!applyPublishCardShop &&
                    <div className={styles.contentContainer}>
                        <div className={styles.title}>
                            商家信息
                        </div>
                        <div className={styles.row}>
                            <img src={shopLogo} className={styles.head} />
                            <div className={styles.infoContainer}>
                                <div className={styles.info}>
                                    <span className={styles.cell}>{shopName}</span>
                                    <span className={styles.cell}>{shopPhone}</span>
                                </div>
                                <div className={styles.info}>
                                    <span className={styles.cell}>{shopAddress}</span>
                                </div>
                                <div className={styles.info}>
                                    <span className={styles.cell}>注册资金：{registerCapital} 万</span>
                                    <span className={styles.cell}>申请额度：{applyAmount} 万</span>
                                </div>
                            </div>
                            {
                                passed === 1 ?
                                    <img src='/img/common/passed.png' className={styles.resultIcon} />
                                : passed === 2 ?
                                    <img src='/img/common/refused.png' className={styles.resultIcon} />
                                : null
                            }
                        </div>
                        <div className={styles.title}>
                            商家资质信息
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>营业执照：</span>
                            <img src={license} className={styles.image} />
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>税务登记证：</span>
                            <img src={taxCertificate} className={styles.image} />
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>组织机构代码证：</span>
                            <img src={organizationCertificate} className={styles.image} />
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>开户许可证：</span>
                            <img src={openAccountCertificate} className={styles.image} />
                        </div>
                        <div className={styles.title}>
                            法人信息
                        </div>
                        <div className={styles.infoContainer}>
                            <div className={styles.info} style={{ marginLeft: 40, marginBottom: 20 }}>
                                <span className={styles.cell}>{legalName}</span>
                                <span className={styles.cell}>{legalPhone}</span>
                            </div>
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>法人身份证正面：</span>
                            <img src={legalIDFront} className={styles.image} />
                        </div>
                        <div className={styles.imageContainer}>
                            <span className={styles.label}>法人身份证背面：</span>
                            <img src={legalIDBack} className={styles.image} />
                        </div>
                        <div className={styles.buttonContainer}>
                            {
                                passed === 0 ?
                                waiting ?
                                    <div style={{ textAlign:'center' }}>
                                        <Spin />
                                        <div>请稍后...</div>
                                    </div>
                                :
                                    <div className={styles.buttonInnerContainer}>
                                        <Button type='primary' onClick={::this.confirmAcceptApply} className={styles.button}>同 意</Button>
                                        <Button type='ghost' onClick={::this.confirmRefuseApply} className={styles.button}>拒 绝</Button>
                                    </div>
                                :
                                null
                            }
                        </div>
                    </div>
                }
            </div>
        );
    }
}
